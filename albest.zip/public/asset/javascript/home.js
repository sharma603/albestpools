
$(document).ready(function() {
    alert("final jquery");
    
});